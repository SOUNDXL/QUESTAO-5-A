<script>
  function calculateDays() {
      var inputDate = prompt("Digite a data no formato dd/mm/aaaa:");
      var datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;

      if (!datePattern.test(inputDate)) {
          alert("Formato incorreto! Por favor, insira a data no formato dd/mm/aaaa.");
          return;
      }

      var parts = inputDate.split('/');
      var userDate = new Date(parts[2], parts[1] - 1, parts[0]); // Convertendo para objeto de data

      var currentDate = new Date();
      var timeDiff = userDate.getTime() - currentDate.getTime();
      var daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));

      var yearsDiff = Math.floor(daysDiff / 365);
      var monthsDiff = Math.floor((daysDiff % 365) / 30);
      daysDiff = daysDiff % 30;

      var message = "Faltam " + yearsDiff + " anos, " + monthsDiff + " meses e " + daysDiff + " dias para a data digitada.";
      alert(message);

      // Mudar a cor de fundo conforme a hora do dia
      var hour = new Date().getHours();
      if (hour >= 6 && hour < 12) {
          document.body.style.backgroundColor = "white";
          document.body.style.color = "black";
      } else if (hour >= 12 && hour < 18) {
          document.body.style.backgroundColor = "yellow";
          document.body.style.color = "black";
      } else if (hour >= 18 && hour < 24) {
          document.body.style.backgroundColor = "black";
          document.body.style.color = "white";
      } else {
          document.body.style.backgroundColor = "blue";
          document.body.style.color = "white";
      }
  }
</script>
</body>
</html>